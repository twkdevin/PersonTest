# Onfido Capture SDK for Android: Sample app

Android application intended to showcase the [Onfido Android SDK](https://github.com/onfido/onfido-android-sdk).

Demo flow emulates a banking app, please don't forget to update `sdk token` in MainActivity to be able to complete flow

You need an Onfido account to use the sample app. Please contact us through our [website](https://onfido.com/signup) to create an Onfido account.