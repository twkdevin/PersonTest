package com.onfido.android.app.sample;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.onfido.android.sdk.capture.ExitCode;
import com.onfido.android.sdk.capture.Onfido;
import com.onfido.android.sdk.capture.OnfidoConfig;
import com.onfido.android.sdk.capture.OnfidoFactory;
import com.onfido.android.sdk.capture.UserEventHandler;
import com.onfido.android.sdk.capture.errors.OnfidoException;
import com.onfido.android.sdk.capture.ui.camera.face.stepbuilder.FaceCaptureStepBuilder;
import com.onfido.android.sdk.capture.ui.options.FlowStep;
import com.onfido.android.sdk.capture.ui.options.stepbuilder.DocumentCaptureStepBuilder;
import com.onfido.android.sdk.capture.upload.Captures;
import com.onfido.android.sdk.capture.utils.CountryCode;
import com.onfido.segment.analytics.Properties;

import org.jetbrains.annotations.NotNull;

import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private Onfido client;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.main);

        findViewById(R.id.next).setOnClickListener(v -> startFlow());

        client = OnfidoFactory.create(this).getClient();
    }

    private void startFlow() {

        FlowStep docuementCaptureStep = DocumentCaptureStepBuilder.forNationalIdentity()
                .withCountry(CountryCode.HK)
                .build();

        FlowStep faceCaptureStep = FaceCaptureStepBuilder.forVideo()
                .withIntro(true)
                .build();

        // Flow Control
        final FlowStep[] flowStepsWithOptions = new FlowStep[]{
                docuementCaptureStep, faceCaptureStep //Both document and video capture together
                // docuementCaptureStep //Document capture flow ONLY
                // faceCaptureStep //Video capture flow ONLY
        };

        startFlow(flowStepsWithOptions);
    }

    private void startFlow(final FlowStep[] flowSteps) {

        //After backend provided SDK token to mobile, put it here
        String sdkToken = "eyJhbGciOiJIUzI1NiJ9.eyJwYXlsb2FkIjoieHVlQmhQOWlEdG01SjQ2SDFhYldpTy9DQThHbXUzNkh2dHZ0eTBuelZkRlR1cjdsdmYweXh6ZnlYWStxXG4xQUo1dGZMQXRGa3JCT1JMQXQxdThaNmRlSHJ5MXBqZGUxZnNnN3pmOURxS1FFSmZva3ZuMDZVSTV6anFcbjA4UWFtQ0RZXG4iLCJ1dWlkIjoiUlpPZUZRQ0xDbG0iLCJleHAiOjE1OTYzNDQ4NjIsInVybHMiOnsib25maWRvX2FwaV91cmwiOiJodHRwczovL2FwaS5vbmZpZG8uY29tIiwidGVsZXBob255X3VybCI6Imh0dHBzOi8vdGVsZXBob255Lm9uZmlkby5jb20iLCJkZXRlY3RfZG9jdW1lbnRfdXJsIjoiaHR0cHM6Ly9zZGsub25maWRvLmNvbSIsInN5bmNfdXJsIjoiaHR0cHM6Ly9zeW5jLm9uZmlkby5jb20iLCJob3N0ZWRfc2RrX3VybCI6Imh0dHBzOi8vaWQub25maWRvLmNvbSJ9fQ.74ehF5YnqFssOWXlQ0LjN6PU1xJ1c4KcTGd0dsAA4wg";

        OnfidoConfig onfidoConfig =
                OnfidoConfig.builder(MainActivity.this)
                        .withSDKToken(sdkToken)
                        .withCustomFlow(flowSteps)
                        .withLocale(Locale.TRADITIONAL_CHINESE) //For Chinese Local
                        .build();

        client.startActivityForResult(MainActivity.this, 1, onfidoConfig);

        // Can get AA data here
        // In user requirement, call backend to start to get autofill OCR when customer arrived backside HKID image capture screen
        client.Companion.setUserEventHandler(new UserEventHandler() {
            @Override
            public void handleEvent(@NotNull String eventName, @NotNull Properties eventProperties) {
                System.out.println("Event: " + eventName);
                System.out.println("Properties: " + eventProperties.toString());
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        client.handleActivityResult(resultCode, data, new Onfido.OnfidoResultListener() {
            @Override
            public void userExited(@NonNull ExitCode exitCode) {
                showToast("User cancelled.");
            }

            @Override
            public void userCompleted(@NonNull Captures captures) {
                startCheck(captures);
            }

            @Override
            public void onError(OnfidoException e) {
                e.printStackTrace();
                showToast("Unknown error");
            }
        });
    }

    private void showToast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void startCheck(Captures captures) {
        //Call your back end to initiate the check https://github.com/onfido/onfido-android-sdk#2-creating-a-check
    }
}
