#### What was the expected behaviour?

#### What happened instead?

#### Version info:

- `onfido-capture-sdk` version:
- Android API version(s):

- `compileSdkVersion`:
- `targetSdkVersion`:
- `minSdkVersion`:
- Support library version (if applicable):

#### Steps to reproduce:

#### Onfido Flow initialization code:

#### Issue severity information (number of users/crashes if applicable):

#### Additional LogCat output:

#### Other useful info:
_screenshots, videos, etc._
